window.onload=function(){
	waterfall('main','pin');
	var dataInt={'data':[{'src':'1.jpg'},{'src':'2.jpg'},{'src':'3.jpg'},{'src':'4.jpg'}]};
	
	window.onscroll=function(){
		if(cheackScrollSlide()){
			var oParent = document.getElementById('main');// 父级对象
			//将数据块渲染到页面的尾部
            for(var i=0;i<dataInt.data.length;i++){
                var oPin=document.createElement('div'); //添加 元素节点
                oPin.className='pin';                   //添加 类名 name属性
                oParent.appendChild(oPin);              //添加 子节点
                var oBox=document.createElement('div');
                oBox.className='box';
                oPin.appendChild(oBox);
                var oImg=document.createElement('img');
                oImg.src='./images/'+dataInt.data[i].src;
                oBox.appendChild(oImg);
            }
            waterfall('main','pin');
		}
	}
}

function waterfall(parent,pin){
	//将main下所有class为box的元素取出来
	var oParent=document.getElementById(parent)
	var oBoxs=getByClass(oParent,pin);
	//console.log(oBoxs.length);
	//计算整个页面显示的列数（页面宽/box的宽）
	var oBoxW=oBoxs[0].offsetWidth;
	console.log(oBoxW);
	var cols=Math.floor(document.documentElement.clientWidth/oBoxW);
	console.log(cols);
	//设置main宽度
	oParent.style.cssText='width:'+oBoxW*cols+'px;margin:0 auto;';//设置父级居中样式：定宽+自动水平外边距
	var hArr=[];//数组放的每一列的累加高  不断更新
	for (var i=0;i<oBoxs.length;i++) {
		if(i<cols){
			hArr.push(oBoxs[i].offsetHeight);
		}else{//到第二行
			var minH=Math.min.apply(null,hArr);
			console.log(minH);
			var index=getMinhIndex(hArr,minH);
			oBoxs[i].style.position='absolute';
			oBoxs[i].style.top=minH+'px';
			//oBoxs[i].style.left=oBoxW*index+'px';
			oBoxs[i].style.left=oBoxs[index].offsetLeft+'px';
			hArr[index]+=oBoxs[i].offsetHeight;//更新hAr
		}
	}
	console.log(hArr);
}

//根据class获取元素
function getByClass(parent,clsName){
	var boxArr=new Array(),//用来存储所获取的所有class为box的元素
		oElements=parent.getElementsByTagName("*");
	for(var i=0;i<oElements.length;i++){
		if(oElements[i].className==clsName){
			boxArr.push(oElements[i]);
		}
	}
	return boxArr;
}
/****
    *获取 pin高度 最小值的索引index
    */
function getMinhIndex(arr,minH){
	for(var i in arr){
        if(arr[i]==minH){
            return i;
        }
    }
}

function cheackScrollSlide(){
	var oParent= document.getElementById('main');
    var oBoxs=getByClass(oParent,'pin');//所有盒子
    //创建【触发添加块框函数waterfall()】的高度：最后一个块框的距离网页顶部+自身高的一半(实现未滚到底就开始加载)
    var lastBoxH=oBoxs[oBoxs.length-1].offsetTop+Math.floor(oBoxs[oBoxs.length-1].offsetHeight/2);
    var scrollTop=document.documentElement.scrollTop||document.body.scrollTop;//注意解决兼容性  滚走的距离
    var documentH=document.documentElement.clientHeight;//页面高度
    console.log(documentH);
    return (lastBoxH<scrollTop+documentH)?true:false;//到达指定高度后 返回true，触发waterfall()函数
}
